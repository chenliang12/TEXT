CREATE TRIGGER TR_U_USER
BEFORE INSERT
  ON U_USER
FOR EACH ROW
  DECLARE
    new_id NUMBER;
  begin
    select seq_u_user.nextval into new_id from dual;
    :NEW.U_ID:=new_id;
  end;
/
