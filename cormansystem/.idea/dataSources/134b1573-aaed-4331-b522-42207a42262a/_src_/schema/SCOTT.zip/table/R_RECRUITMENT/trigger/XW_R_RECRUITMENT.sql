CREATE TRIGGER XW_R_RECRUITMENT
BEFORE INSERT
  ON R_RECRUITMENT
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_r_recruitment.nextval into new_id from dual;
    :new.R_ID:=new_id;
  end;
/
