CREATE TRIGGER XW_D_DEPARTMENT
BEFORE INSERT
  ON D_DEPARTMENT
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_d_department.nextval into new_id from dual;
    :new.D_ID:=new_id;
  end;
/
