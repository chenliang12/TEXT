CREATE TRIGGER XW_T_TRAIN
BEFORE INSERT
  ON T_TRAIN
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_t_train.nextval into new_id from dual;
    :new.T_ID:=new_id;
  end;
/
