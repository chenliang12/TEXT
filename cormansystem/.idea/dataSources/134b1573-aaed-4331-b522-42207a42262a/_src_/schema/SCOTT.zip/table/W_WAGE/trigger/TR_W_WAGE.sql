CREATE TRIGGER TR_W_WAGE
BEFORE INSERT
  ON W_WAGE
FOR EACH ROW
  DECLARE
    new_id NUMBER;
  begin
    select seq_w_wage.nextval into new_id from dual;
    :NEW.W_ID:=new_id;
  end;
/
