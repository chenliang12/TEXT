CREATE TRIGGER XW_R_REANDPUN
BEFORE INSERT
  ON R_REANDPUN
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_r_reandpun.nextval into new_id from dual;
    :new.RE_ID:=new_id;
  end;
/
