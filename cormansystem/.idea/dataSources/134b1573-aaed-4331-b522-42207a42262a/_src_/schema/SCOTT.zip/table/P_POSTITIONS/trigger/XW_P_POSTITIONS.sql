CREATE TRIGGER XW_P_POSTITIONS
BEFORE INSERT
  ON P_POSTITIONS
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_p_postitions.nextval into new_id from dual;
    :new.P_ID:=new_id;
  end;
/
