CREATE TRIGGER XW_A_ATTENDANCE
BEFORE INSERT
  ON A_ATTENDANCE
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_a_attendance.nextval into new_id from dual;
    :new.A_ID:=new_id;
  end;
/
