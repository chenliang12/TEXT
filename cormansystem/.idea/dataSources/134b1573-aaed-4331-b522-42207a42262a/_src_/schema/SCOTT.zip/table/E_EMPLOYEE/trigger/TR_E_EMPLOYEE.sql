CREATE TRIGGER TR_E_EMPLOYEE
BEFORE INSERT
  ON E_EMPLOYEE
FOR EACH ROW
  DECLARE
    new_id NUMBER;
  begin
    select seq_e_employee.nextval into new_id from dual;
    :NEW.E_ID:=new_id;
  end;
/
