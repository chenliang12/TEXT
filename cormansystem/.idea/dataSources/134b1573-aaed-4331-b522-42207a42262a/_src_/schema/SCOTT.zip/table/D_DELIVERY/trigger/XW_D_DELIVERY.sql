CREATE TRIGGER XW_D_DELIVERY
BEFORE INSERT
  ON D_DELIVERY
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_d_DELIVERY.nextval into new_id from dual;
    :new.DE_ID:=new_id;
  end;
/
