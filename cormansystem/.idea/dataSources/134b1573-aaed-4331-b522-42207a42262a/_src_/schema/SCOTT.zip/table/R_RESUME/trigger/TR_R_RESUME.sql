CREATE TRIGGER TR_R_RESUME
BEFORE INSERT
  ON R_RESUME
FOR EACH ROW
  DECLARE
    new_id NUMBER;
  begin
    select seq_r_resume.nextval into new_id from dual;
    :NEW.R_ID:=new_id;
  end;
/
