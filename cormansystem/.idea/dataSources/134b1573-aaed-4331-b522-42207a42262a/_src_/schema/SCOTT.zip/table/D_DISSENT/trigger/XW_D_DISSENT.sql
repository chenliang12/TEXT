CREATE TRIGGER XW_D_DISSENT
BEFORE INSERT
  ON D_DISSENT
FOR EACH ROW
  DECLARE
 new_id NUMBER;
  begin
    select xw_d_dissent.nextval into new_id from dual;
    :new.D_ID:=new_id;
  end;
/
